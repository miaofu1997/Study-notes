function y = squareThisNumber(x)

y = x^2;