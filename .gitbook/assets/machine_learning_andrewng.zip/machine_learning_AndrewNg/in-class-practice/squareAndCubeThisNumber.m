function [y1, y2] = squareAndCubeThisNumber(x)

y1 = x^2;
y2 = x^3;